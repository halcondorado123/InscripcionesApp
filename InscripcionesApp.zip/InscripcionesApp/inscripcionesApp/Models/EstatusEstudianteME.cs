﻿namespace InscripcionesApp.Models
{
    public class EstatusEstudianteME
    {
        public int Estatus_Est_ID { get; set; }
        public string? Estatus_Estudiante { get; set; }
    }
}
