﻿namespace InscripcionesApp.Models
{
    public class RolME
    {
        public int? RolID { get; set; }
        public string? TipoRol { get; set; }

    }
}
