var builder = WebApplication.CreateBuilder(args);

// Agregar la configuraci�n desde el archivo appsettings.json
builder.Configuration.AddJsonFile("appsettings.json", optional: false);

// Obtener la cadena de conexi�n desde la configuraci�n
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Agregar la cadena de conexi�n como servicio
builder.Services.AddSingleton(connectionString);

// Agregar otros servicios necesarios
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configurar el middleware y el enrutamiento
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
