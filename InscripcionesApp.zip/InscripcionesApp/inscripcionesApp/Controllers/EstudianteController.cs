﻿using Microsoft.AspNetCore.Mvc;

namespace InscripcionesApp.Controllers
{
    public class EstudianteController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
