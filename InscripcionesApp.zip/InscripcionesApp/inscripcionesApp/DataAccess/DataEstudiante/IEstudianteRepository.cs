﻿using inscripcionesApp.Models;

namespace InscripcionesApp.DataAccess.DataEstudiante
{
    public interface IEstudianteRepository
    {
        Task CrearRegistroLibro(EstudianteME estudiante);
    }
}

